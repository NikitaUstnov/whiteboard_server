export interface User {
  id: string;
  joinedAt: Date;
  userName: string;
}
