export interface CursorPosition {
  x: number;
  y: number;
}

export interface CursorData {
  position: CursorPosition;
  color: string;
}
